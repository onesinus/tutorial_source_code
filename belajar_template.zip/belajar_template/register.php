<?php	
	include "koneksi.php";

	// mengambil nilai dari yang di input di form login
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	
	// perintah untuk mendapatkan user dari db berdasarkan nama yang di input di form login
	$get_user = "INSERT INTO users(email, password) VALUES('$email', '$password')";
	$result = mysqli_query($konek,$get_user);
	
	if($result){
		Header("Location: login.html");
	}
?>